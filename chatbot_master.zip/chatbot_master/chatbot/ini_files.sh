rm solvedatacp/plans/*.*
rm solvedatacp/noplans/*.*
cp 00_delta0_base.txt ../sdata/

