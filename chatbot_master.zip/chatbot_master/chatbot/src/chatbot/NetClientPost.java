/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatbot;

/**
 *
 * @author jorge
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jorge
 */

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;

public class NetClientPost {
    public static void main(String[] args) {
        String urlParameters  = "";
        //String targetURL = "https://cognitiveplanning.azurewebsites.net/cognitive_planning/brev/?parameters=x_env_land_x,x_intens_high_x,x_soc_single_x";
        //String targetURL = "https://cognitiveplanning.azurewebsites.net/cognitive_planning/brev/?parameters=x_env_land_x,x_intens_med_x,x_soc_team_x";
        //String targetURL   = "https://cognitiveplanning.azurewebsites.net/cognitive_planning/brev/?parameters=x_env_land_x,x_loc_outdoor_x,x_cost_high_x";
        String targetURL   = "https://cognitiveplanning.azurewebsites.net/cognitive_planning/brev/?parameters=x_env_water_x,x_intens_high_x,x_cost_med_x";
        //String targetURL = "https://cognitiveplanning.azurewebsites.net/cognitive_planning/brev/?parameters=x_env_water_x,x_intens_low_x";
        //String targetURL = "https://cognitiveplanning.azurewebsites.net/cognitive_planning/brev/?parameters=x_env_land_x,x_intens_high_x";
        //String targetURL = "https://cognitiveplanning.azurewebsites.net/cognitive_planning/brev/?parameters=x_env_land_x,x_intens_med_x,x_loc_indoor_x";
        
        
        URL url;
        HttpsURLConnection connection = null; 
    
        try {
            //Create connection
            url = new URL(targetURL+urlParameters);
            connection = (HttpsURLConnection)url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type","application/json");
            connection.setRequestProperty("Content-Length", "" + Integer.toString(urlParameters.getBytes().length));
            connection.setRequestProperty("Accept-Charset", "UTF-8"); 
            connection.setRequestProperty("Accept", "application/json");
            connection.setUseCaches (false);
            connection.setDoInput(true);
            connection.setDoOutput(true);            
            
            try (   //Send request
                    DataOutputStream wr = new DataOutputStream (
                    connection.getOutputStream ())) {
                    wr.writeBytes (urlParameters);
                    wr.flush ();
                
                    //Get Response
                    InputStream is = connection.getInputStream();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(is));
                    String line;
                    StringBuffer response = new StringBuffer();
                    while((line = rd.readLine()) != null) {
                    response.append(line);
                    response.append('\r');
                    }
                    rd.close();
                    System.out.println(response.toString());
            }

        } catch (Exception e) {
              e.printStackTrace();
    } finally {

      if(connection != null) {
        connection.disconnect(); 
      }
    }
  }
 }