/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatbot;

/**
 *
 * @author jorge
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.font.FontRenderContext;
import java.awt.font.LineBreakMeasurer;
import java.awt.font.TextAttribute;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.Math;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.AttributedCharacterIterator;
import java.text.AttributedString;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

public class ChatBot extends JFrame implements KeyListener{

        
    
	JPanel p=new JPanel();
        JButton resetButton = new JButton("reset");
        JButton playButton = new JButton("Play");
        String basePath = new File("").getAbsolutePath();
        int lastIndxDot = basePath.lastIndexOf('/');
        String basePath0 = basePath.substring(0, lastIndxDot);
        int argSize = 8;
        Thread myThreads[] = new Thread[argSize];
        String[] array_opt; 
        
        int j;
        int i = 0;    
   
        
	//JTextArea dialog=new JTextArea(20,60);
        
        JTextPane dialog = new JTextPane();
        StyledDocument doc = dialog.getStyledDocument();
        
	JTextArea input=new JTextArea(0,59);
        
	JScrollPane scroll=new JScrollPane(
		dialog,
		JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
		JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
	);
        
        
	JScrollPane scroll2=new JScrollPane(
		input,
		JScrollPane.VERTICAL_SCROLLBAR_NEVER,
		JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
	);
        
	
	String[][] chatBot={
		//standard greetings
		{"hi","hello","hola","ola","howdy"},
                {"hi, would you like to set the variables ?"},
                
		{"yes"},
                {"call_yes"},                
		//{"call_individual"},                
                
                
                
		//question greetings
		{"how are you","how r you","how r u","how are u"},
		{"good","doing well"},
		//yes
		{"no so good","I feel pain"},
		{"do you take the medicine ?"},
                
                /*
		{"no", "no yet"},
		{"why ? Options : 1. Feel pain / 2. Have fever"},
                */
		//default

		{"1"},
		{"Do you think the medicine produce the pain ?"},
                

                
		{"no"},
                {"call_no"},
		//{"Would you like to setup a conditional desire ?"},                
		//default                
                
		//{"yes","ok"},
		//{"call_conditional"},                  
                
		{"finish"},
		{"call_plan"},                  
                
                
                
		{"Sorry, I don't understand"}
	};
	
	public static void main(String[] args) throws IOException {
		new ChatBot();
	}
    File file;
	
	public ChatBot() throws FileNotFoundException, IOException{
		super("Chat Bot");
		setSize(700,400);
                
                System.out.println("Current directory : "+ basePath);
                System.out.println("Parent directory : "+ basePath0);
                
            BufferedReader br = new BufferedReader(new FileReader("../sdata/00_axioms.touist"));
            StringBuilder sb = new StringBuilder();
            String line = "";
            

            while ((line = br.readLine()) != null) {

                if (line.startsWith("$Opt")) {
                    System.out.println(line);
                    
                    String s = line;

                    s = s.substring(s.indexOf("[") + 1);
                    s = s.substring(0, s.indexOf("]"));
                    
                    //Read the $Opt set (Sports) in the 00_axioms.touist file
                    String[] array = s.split(",");
                    //String array_opt[]; 
                    
                    array_opt = new String[array.length];
                    
                    for (int i = 0; i < array.length; i++)
                                            array_opt[i] = array[i].trim();
                            
                    for (String element: array_opt) {
                               System.out.println(element);
                           }

                    
                    break;
                }
            }                


                
                
                
                
          
                
		//setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		dialog.setEditable(true);
		input.addKeyListener(this);
                scroll.setPreferredSize(new Dimension(650, 300));              
	
		p.add(scroll);
                p.add(scroll2);
		//p.add(input);

		p.setBackground(new Color(255,200,0));
		add(p);
		setVisible(true);

                        String st;
                        st = "Hi! How are you?, I am Botty your personal assistant";
                        addText2(" Agent : \t"+st,1);     
                        st = "I will help you to find the best sport based in your preferences";
                        addText2("\n Agent : \t"+st,1);                         
                        st = "Are you ready to start ?";
                        addText2("\n Agent : \t"+st,1);                                                 
                        
                        input.setText(null);
                        input.grabFocus();
                        
                        File f= new File(basePath+"/solvedatacp/plan_final_show*");   //file to be delete  
                        File f3= new File(basePath0+"/sdata/00_delta0_base.txt");   //file to be delete                          
                        File f4= new File(basePath0+"/chatbot/solvedatacp/plans");   //file to be delete                          
                        File f5= new File(basePath0+"/chatbot/solvedatacp/noplans");   //file to be delete                          
                        
                        f.delete();
                        f3.delete();
                        //f4.delete();
                        deleteDirectory(f4);
                        deleteDirectory(f5);
                        
                        try {
                            File file = new File(basePath0+"/sdata/00_delta0_base.txt");
                            file.createNewFile();
                            System.out.println("Empty File Created:- " + file.length());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }


	}
	
	public void keyPressed(KeyEvent e){
		if(e.getKeyCode()==KeyEvent.VK_ENTER){
			input.setEditable(false);
                        
                        
			String quote=input.getText();
			input.setText("");
			addText2("\n"+quote.trim()+"\t : Human ",2);
			while(
				quote.charAt(quote.length()-1)=='!' ||
				quote.charAt(quote.length()-1)=='.' ||
				quote.charAt(quote.length()-1)=='?'
			){
				quote=quote.substring(0,quote.length()-1);
			}
			
                        //System.out.println ("Human input :: #"+ quote+"#");
                        //System.out.println ("Human input :: @"+ quote.trim()+"@");
                        
			byte response=0;
			//-----check for matches----
			int j=0;//which group we're checking
			while(response==0){
				if(inArray(quote.trim().toLowerCase(),chatBot[j*2])){
                                    try {
                                        response=2;
                                        int r=(int)Math.floor(Math.random()*chatBot[(j*2)+1].length);
                                        String s = chatBot[(j*2)+1][r];
                                        
                                        
                                        int nl = countLines(dialog);
                                        String lq = "";
                                        System.out.println ("Numero de Linea :: \n"+nl);
                                        lq = getLine(dialog, nl - 1);
                                        //System.out.println ("Last Question   :: \n"+ lq);
                                        
                                        
                                        
                                        //if ("call_yes".equals(s) && (" Agent : 	Would you like to setup a conditional desire ?".equals(lq.trim()) || " Agent : 	hi, would you like to set the variables ?".equals(lq.trim()) )) {
                                        if ("call_yes".equals(s) && ("Agent : 	Do you want to continue adding more individual desires ?".equals(lq.trim()) || "Agent : 	hi, would you like to set the variables ?".equals(lq.trim()) || "Agent : 	Are you ready to choose your preferences ?".equals(lq.trim()) )) {
                                            
                                            try {
                                                MyDialog1 dlg = new MyDialog1(this);
                                                String[] results = dlg.run();
                                                /*if (results[0] != null) {
                                                JOptionPane.showMessageDialog(this,
                                                "Variable = "+ results[1] + ", Value = " + results[0]);
                                                }*/
                                                
                                                String st;
                                                st = "You selected : ";
                                                addText2("\n Agent : \t"+st,1);
                                                
                                                st = results[1] +" = " + results[0];
                                                addText2(st,3);
                                                
                                                /*************/
                                                String assigment = "";
                                                String assigmentx = "";
                                                
                                                if (results[0].indexOf("not") >= 0) {
                                                    results[0] = results[0].replace("not ","");
                                                    assigment = "not ass("+results[1]+","+results[0]+")";
                                                    assigmentx = "not x_"+results[1]+"_"+results[0]+"_x";
                                                } else {
                                                    assigment = "ass("+results[1]+","+results[0]+")";
                                                    assigmentx = "x_"+results[1]+"_"+results[0]+"_x";
                                                }
                                                
                                                
                                                
                                                
                                                ////////////////////////
                                                //////////////////////// @@@
                                                
                                                saveInput(assigmentx);
                                                
                                                
                                                
                                                
                                                //System.out.println ("Insert into /sdata/00_delta0.txt :: "+assigment);
                                                /***********/
                                                
                                                st = "Do you want to continue adding more individual desires ?";
                                                addText2("\n Agent : \t"+st,1);
                                                
                                                input.setEditable(true);
                                                
                                            } catch (Exception ex) {
                                                Logger.getLogger(ChatBot.class.getName()).log(Level.SEVERE, null, ex);
                                            }
                                        } //else if (s == "call_conditional") {
                                        else if ("call_yes".equals(s) && "Agent : 	Would you like to setup a conditional desire ?".equals(lq.trim())) {                                         
                                            try {
                                                MyDialog2 dlg = new MyDialog2(this);
                                                String[] results = dlg.run();
                                                /*if (results[0] != null) {
                                                JOptionPane.showMessageDialog(this,
                                                "Variable = "+ results[1] + ", Value = " + results[0]+"\n"+
                                                "Variable = "+ results[3] + ", Value = " + results[2]        );
                                                }*/
                                                
                                                String st;
                                                st = "You selected : ";
                                                addText2("\n Agent : \t"+st,1);
                                                
                                                st = results[1] +" = " + results[0]+"=>"+ results[3] +" = " + results[2];
                                                addText2(st,3);
                                                
                                                /*************/
                                                String assigment = "";
                                                String assigmentx = "";
                                                
                                                if (results[0].indexOf("not") >= 0) {
                                                    assigment = "not ass("+results[1]+","+results[0]+")";
                                                    assigmentx = "not x_"+results[1]+"_"+results[0]+"_x";
                                                    
                                                } else {
                                                    assigment = "ass("+results[1]+","+results[0]+") => ass("+results[3]+","+results[2]+")";
                                                    assigmentx = "x_"+results[1]+"_"+results[0]+"_x => x_"+results[3]+"_"+results[2]+"_x";
                                                    
                                                }
                                                
                                                saveInput(assigmentx);
                                                
                                                /*System.out.println ("Insert into 00_HUMAN :: "+assigment);*/
                                                System.out.println ("Insert into /sdata/00_delta0.txt :: "+assigment);
                                                /***********/
                                                
                                                st = "Would you like to setup a conditional desire ?";
                                                addText2("\n Agent : \t"+st,1);
                                                
                                                input.setEditable(true);
                                            } catch (Exception ex) {
                                                Logger.getLogger(ChatBot.class.getName()).log(Level.SEVERE, null, ex);
                                            }
                                            
                                            
                                        }  else if ("call_no".equals(s) && "Agent : 	Do you want to continue adding more individual desires ?".equals(lq.trim())) {                                               
                                            
                                            String st;
                                            st = "Would you like to setup a conditional desire ?";
                                            addText2("\n Agent : \t"+st,1);
                                            
                                        }   else if ("call_no".equals(s) && "Agent : 	Would you like to setup a conditional desire ?".equals(lq.trim())) {                                         
                                            
                                            try {
                                                String st;
                                                st = "Ok, these are your preferences : ";
                                                addText2("\n Agent : \t"+st,1);
                                                ExeProc("pro_show_selections");
                                                st = "Would you like me to find the best sport for you ?";
                                                addText2("\n Agent : \t"+st,1);                                                
                                                
                                            } catch (Exception ex) {
                                                Logger.getLogger(ChatBot.class.getName()).log(Level.SEVERE, null, ex);
                                            }
                                        } else if ("call_yes".equals(s) && "Agent : 	Would you like me to find the best sport for you ?".equals(lq.trim())) {
                                            
                                            try {
                                                String st;
                                                st = "Please wait, I am trying to find the best sport for You ";
                                                addText2("\n Agent : \t"+st,1);
                                                addText2("\n\t",1);
                                                ExeProc("pro_cog_plan");
                                            } catch (Exception ex) {
                                                Logger.getLogger(ChatBot.class.getName()).log(Level.SEVERE, null, ex);
                                            }
                                            
                                        } else if ("call_yes".equals(s) && "Agent : 	Are you ready to start ?".equals(lq.trim())) {
                                            
                                            String st;
                                            st = "Great !, let's start by selecting your desires.";
                                            addText2("\n Agent : \t"+st,1);
                                            st = "Are you ready to choose your preferences ?";
                                            addText2("\n Agent : \t"+st,1);                                            
                                            
                                        } else {
                                            addText2("\n Agent : \t"+s,1);
                                        }
                                    } catch (BadLocationException ex) {
                                        Logger.getLogger(ChatBot.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                    
				}
				j++;
				if(j*2==chatBot.length-1 && response==0){
					response=1;
				}
			}
			
			//-----default--------------
			if(response==1){
				int r=(int)Math.floor(Math.random()*chatBot[chatBot.length-1].length);
				addText("\n Agent : \t"+chatBot[chatBot.length-1][r]);
 			}
			//addText("\n");
		}
                
	}
	
	public void keyReleased(KeyEvent e){
		if(e.getKeyCode()==KeyEvent.VK_ENTER){
			input.setEditable(true);
		}
	}
	
	public void keyTyped(KeyEvent e){}
	
	public void addText(String str){
		dialog.setText(dialog.getText()+str);
	}
        
        
        
        public static void deleteDirectory(File file)
           {
               // store all the paths of files and folders present
               // inside directory
               for (File subfile : file.listFiles()) {

                   // if it is a subfolder,e.g Rohan and Ritik,
                   // recursiley call function to empty subfolder
                   if (subfile.isDirectory()) {
                       deleteDirectory(subfile);
                   }

                   // delete files and empty subfolders
                   subfile.delete();
               }
           }   
        
        
        
        
        
        public String finder( String dirName)
        {
            File dir = new File(dirName);
            if ( dir.isDirectory() )
            {
                String[] list = dir.list(new FilenameFilter()
                {
                    @Override
                    public boolean accept(File f, String s ) 
                    {
                        return s.endsWith(".txt");
                    }

               });
                if ( list.length > 0 )
                {
                    return list[0];
                }
            }
            return "";
        }        
        
        
        
        
        
        
        
        
        

        public void addText2(String txt, int nColor) {
            SwingUtilities.invokeLater(new Runnable() {
               public void run() {
                   if (nColor == 1) {
                       try {
                           //dialog.setText(dialog.getText() + txt);
                           //dialog.update(dialog.getGraphics());
                           SimpleAttributeSet left = new SimpleAttributeSet();
                           StyleConstants.setAlignment(left, StyleConstants.ALIGN_LEFT);
                           StyleConstants.setForeground(left, Color.RED);
                           doc.insertString(doc.getLength(), txt, left );
                           doc.setParagraphAttributes(doc.getLength(), 1, left, false);
                       } catch (BadLocationException ex) {
                           Logger.getLogger(ChatBot.class.getName()).log(Level.SEVERE, null, ex);
                       }
                   } else if (nColor == 2) {
                       try {
                           //dialog.setText(dialog.getText() + txt);
                           //dialog.update(dialog.getGraphics());
                           SimpleAttributeSet right = new SimpleAttributeSet();
                           StyleConstants.setAlignment(right, StyleConstants.ALIGN_RIGHT);
                           StyleConstants.setForeground(right, Color.BLUE);
                           doc.insertString(doc.getLength(), txt, right );
                           doc.setParagraphAttributes(doc.getLength(), 1, right, false);
                       } catch (BadLocationException ex) {
                           Logger.getLogger(ChatBot.class.getName()).log(Level.SEVERE, null, ex);
                       }
                   } else if (nColor == 3) {
                       try {
                           //dialog.setText(dialog.getText() + txt);
                           //dialog.update(dialog.getGraphics());
                           SimpleAttributeSet left = new SimpleAttributeSet();
                           StyleConstants.setAlignment(left, StyleConstants.ALIGN_LEFT);
                           StyleConstants.setForeground(left, Color.BLACK);
                           doc.insertString(doc.getLength(), txt, left );
                           doc.setParagraphAttributes(doc.getLength(), 1, left, false);
                       } catch (BadLocationException ex) {
                           Logger.getLogger(ChatBot.class.getName()).log(Level.SEVERE, null, ex);
                       }
                   }
                  
                  
               }
            });
          }
        
        
        public String ReadFromFile2(String fileName, int rev) throws IOException {
            StringBuilder everything = new StringBuilder();
            String line;
            String[] linex;
            linex = new String[20];
            String preText = null;
            int i=0;
            
            File file = new File(fileName);
            BufferedReader buffIn = new BufferedReader(new FileReader(file)); 
                
            if (rev == 1) {
                while( (line = buffIn.readLine()) != null) {
                   i ++;     
                   linex[i] = line;
                }

                while( i > 0) {
                   everything.append(linex[i]);
                   everything.append("\n\t");
                   i --; 
                }            

                //preText = "This is the best plan for you : \n\t";
                preText = "";
            } else if (rev == 0) {
                while( (line = buffIn.readLine()) != null) {
                   i ++;     
                   linex[i] = line;
                   everything.append(linex[i]);
                   everything.append("\n\t");
                }            
            
                preText = "";
            }
            return preText +"\n\t"+everything.toString();
        }  
        
        
        
        
        
        public static boolean isEmptyDirectory(File directory)
                throws IOException
            {
                // check if given path is a directory
                if (directory.exists()) {
                    if (!directory.isDirectory()) {

                        // throw exception if given path is a
                        // file
                        throw new IllegalArgumentException(
                            "Expected directory, but was file: "
                            + directory);
                    }
                    else {
                        // create a stream and check for files
                        try (DirectoryStream<Path> directoryStream
                             = Files.newDirectoryStream(
                                 directory.toPath())) {
                            // return false if there is a file
                            return !directoryStream.iterator()
                                        .hasNext();
                        }
                    }
                }
                // return true if no file is present
                return true;  
            }    


        
        
        
        
        
        public void ExeProc(String plan) throws Exception  {  
    
        String s;
        Process p;
        try {
            
            switch (plan) {

                case "pro_brev":
                    p = Runtime.getRuntime().exec(basePath0+"/brev/brev -e s score.txt 00_delta0_base.txt 04_input.txt");
                    BufferedReader br2b = new BufferedReader(
                        new InputStreamReader(p.getInputStream()));
                    while ((s = br2b.readLine()) != null)
                        System.out.println("line: " + s);
                    p.waitFor();
                    System.out.println ("exit: " + p.exitValue());
                    p.destroy();   
                    break;                    
                    
                case "pro_show_selections":
                    
                    String st="";
                    st = ReadFromFile2(basePath0+"/sdata/00_delta0.txt",0);
                    addText2("\t"+st,3);                  
                    break;                         
                    
                case "pro2":
                    p = Runtime.getRuntime().exec(basePath0+"/brev/brev -e s score.txt svol.txt sinput2.txt");
                    BufferedReader br2 = new BufferedReader(
                        new InputStreamReader(p.getInputStream()));
                    while ((s = br2.readLine()) != null)
                        System.out.println("line: " + s);
                    p.waitFor();
                    System.out.println ("exit: " + p.exitValue());
                    p.destroy();   
                    break;
                    
                case "pro3":
                    p = Runtime.getRuntime().exec(basePath0+"/brev/brev -e s score.txt svol.txt sinput3.txt");
                    BufferedReader br3 = new BufferedReader(
                        new InputStreamReader(p.getInputStream()));
                    while ((s = br3.readLine()) != null)
                        System.out.println("line: " + s);
                    p.waitFor();
                    System.out.println ("exit: " + p.exitValue());
                    p.destroy();                       
                    break;
                    
                case "pro_cog_plan":    
                    
                    p = Runtime.getRuntime().exec(basePath+"/translator.exe --solve "+basePath0+"/sdata/00_delta0.txt");
                    
                    BufferedReader br4 = new BufferedReader(
                        new InputStreamReader(p.getInputStream()));
                    while ((s = br4.readLine()) != null)
                        System.out.println("line: " + s);
                    p.waitFor();
                    System.out.println ("exit: " + p.exitValue());
                    p.destroy();
                    
                    
                    for (j = 0; j < argSize; j++) {

                    /*new MyThread1("sw");
                    new MyThread1("te");
                    new MyThread1("yo");
                    new MyThread1("so");
                    new MyThread1("di");*/
                    new MyThread1(array_opt[j]);
                    }
                    //new MyThread("Two");

                
                    
                    
/**************************/
                    
                    Thread t2 = new Thread(new Runnable() {
                        String s2="";
                        String st=".";
                        String finalplanFile="";
                        String finalplanDir = basePath0+"/chatbot/solvedatacp/plans";
                        String finalnoplanDir = basePath0+"/chatbot/solvedatacp/noplans";
                        int numberFiles = 0;
                        
                        //long numberFilesNoPlan;
                        
                        File directory = new File(basePath+"/solvedatacp/plans");   
                        //File directoryNP = new File(basePath+"/solvedatacp/plans");
                        
                        File hugeDir = new File(finalnoplanDir);
                        
                        
                        @Override
                        public void run() {
                            try {
                                // code goes here.
                                    //while(!needed_01.exists() && !needed_02.exists() && !needed_03.exists() && !needed_04.exists() && !needed_05.exists() && !needed_06.exists() && !needed_07.exists() && !needed_08.exists() ){
                                    //while(!needed_04.exists()){
                                    while(isEmptyDirectory(directory) && numberFiles < argSize){
                                      Thread.sleep(500); //sleep for 2 seconds.. MUST DO THIS
                                      numberFiles = hugeDir.list().length;
                                      addText2(st,1);
                                    }  
                                    

                                    String s;
                                    Process p;
                                    try {
                                       
                                        p = Runtime.getRuntime().exec("pkill planer");
                                        BufferedReader br = new BufferedReader(
                                            new InputStreamReader(p.getInputStream()));
                                        while ((s = br.readLine()) != null)
                                            System.out.println("line: " + s);
                                        p.waitFor();
                                        System.out.println ("exit: " + p.exitValue());
                                        p.destroy();
                                    } catch (Exception e) {}

                                   
                                    if (numberFiles == argSize) {
                                        finalplanFile = finder(finalnoplanDir);
                                        st = ReadFromFile2(finalnoplanDir+"/"+finalplanFile,0);                                        
                                        
                                    } else {
                                        finalplanFile = finder(finalplanDir);
                                        st = ReadFromFile2(finalplanDir+"/"+finalplanFile,0);
                                    }
                                    addText2("\n Agent : \t"+st,1);
                                    
                                    
                                    
                            } catch (InterruptedException ex) {
                                Logger.getLogger(ChatBot.class.getName()).log(Level.SEVERE, null, ex);
                            } catch (IOException ex) {
                                Logger.getLogger(ChatBot.class.getName()).log(Level.SEVERE, null, ex);
                            }

                        }
                    });  
                    t2.start();                      
                    
                    
                    
                    
                    

                    break;
                    
                    
                case "pro6":
                    
                    break;
                default: 
                    
                    break;
                }            
            
            
        } catch (Exception e) {}
    
}

        
	public boolean inArray(String in,String[] str){
		boolean match=false;
		for(int i=0;i<str.length;i++){
			if(str[i].equals(in)){
				match=true;
			}
		}
		return match;
	}
        
       
        
        public String setVars() throws Exception  {
         String desc1="";
         
                    try {
                        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                    }

                    JFrame f = new JFrame("Lister v1.0");
                    f.setSize(300, 300);
                    f.setLocation(300, 300);
                    f.addWindowListener(new WindowAdapter( ) {
                      @Override
                      public void windowClosing(WindowEvent we) { System.exit(0); }
                    });                    
                    
                    String [] items1 = { "land", "water" };                    
                    String [] items2 = {"indoor", "outdoor", "mixed"};  
                    
                    
                    // put the controls the content pane
                    Container c = f.getContentPane();
                    JPanel panel = new JPanel();
                    
                    panel.add(new JLabel("Please make a selection:"));
                    DefaultComboBoxModel model = new DefaultComboBoxModel();
                    final JList list = new JList(items1);
                    
                    JButton button = new JButton("Per favore");
                        button.addActionListener(new ActionListener( ) {
                          public void actionPerformed(ActionEvent ae) {
                            Object[] selection = list.getSelectedValues( );
                            System.out.println("-----");
                            for (int i = 0; i < selection.length; i++)
                              System.out.println(selection[i]);
                          }
                        });                    
                    
                    
                    model.addElement("env");
                    model.addElement("loc");
                    model.addElement("cost");
                    JComboBox comboBox = new JComboBox(model);
                    panel.add(comboBox);
                    
                    
                    c.add(panel, BorderLayout.NORTH);
                    c.add(new JScrollPane(list), BorderLayout.CENTER);
                    c.add(button, BorderLayout.SOUTH);

                    f.setVisible(true);                    
                    

                    /*int result = JOptionPane.showConfirmDialog(null, panel, "Flavor", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);*/
                    
                    
                    String svar;
                    svar = comboBox.getSelectedItem().toString();
                    
                    switch (svar) {
                        case "env":
                            list.setListData(items2);
                            break;
                    }
                    
            return desc1;
        }        





        public int countLines(JTextPane textArea) {
            String text = textArea.getText();
            String lines[];
            lines = text.split("\n");
            int count = lines.length;
            System.out.println ("COUNT LINES \n: "+count);
            return count;
            
        }    
        
        
        public String getLine(JTextPane textArea, int numLine) throws BadLocationException {        
            Document doc = textArea.getDocument();
            Element root = doc.getDefaultRootElement();
            Element element = root.getElement(numLine);
            int start = element.getStartOffset();
            int end = element.getEndOffset();
            System.out.println(doc.getText(start, end - start));        
            return doc.getText(start, end - start);
        }    
        
        
        
	//public void saveInput(String assigment) 
        public void saveInput(String input) throws IOException, Exception {
            

            File f= new File(basePath0+"/sdata/04_input.txt");   //file to be delete  
            f.delete();            
            
            
            String fileName = basePath0+"/sdata/04_input.txt";
	    FileWriter fileWriter = new FileWriter(fileName);
            System.out.println ("Inside saveInput 1");
            try (PrintWriter printWriter = new PrintWriter(fileWriter)) {
                System.out.println ("Inside saveInput 2");
                //printWriter.print("Some String");
                printWriter.printf(input);
            }

            ExeProc("pro_brev");
            
            
            
	}        
        
    
    
}