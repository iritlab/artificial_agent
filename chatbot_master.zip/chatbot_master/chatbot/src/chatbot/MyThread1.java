/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatbot;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

class MyThread1 implements Runnable {
String name;
String lang = "1"; //1 = English
Process p2a;
String basePath = new File("").getAbsolutePath();
int lastIndxDot = basePath.lastIndexOf('/');
String basePath0 = basePath.substring(0, lastIndxDot);
Boolean isAlive2;

Thread t;
    MyThread1 (String thread){
    name = thread; 
    
    t = new Thread(this, name);
    System.out.println("New thread: " + t);
    t.start();
    
    //vivo2 = t.isAlive();
}

public void run() {
    try {
        // code goes here.
        //startTime = System.currentTimeMillis();
        p2a = Runtime.getRuntime().exec(basePath0+"/planer/planer -e sat 01_ini_state.txt 02_actions.txt 03_goal.txt "+name+" "+lang);
        //System.out.println("Hilo : "+ j + " Option "+ i + " " +array_opt[i]);
    } catch (IOException ex) {
        Logger.getLogger(MyThread1.class.getName()).log(Level.SEVERE, null, ex);
    }
    System.out.println(name + " running.");
    //isAlive2 = t.isAlive();
}
}