awk '{ tot[$0]++ } END { for (i in tot) print tot[i],i } ' te.out2 | sort -r
