java -jar ChatBot.jar
