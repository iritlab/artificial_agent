open Printf


class t  (model:string) (actions:string) (goal:string) (sport:string) (lang:string) (encoding:int)  =
object (self)


method search = (* notimed_search + *)

let lines = ref [] in 
let tempo_actions = ref [] in 
let linesper = ref [] in 
let linesperx = ref [] in 
let rtn = ref "" in
let filter_list = ref "" in
let action_danger = ref "" in 
let ideal_option = ref "" in 
let ideal_option_danger = ref "" in 
let ideal_sport = ref "" in 
let explanation = ref [] in 
let final_explanation = ref "" in 
let psize = ref 0 in 

let command cmd =
  Sys.command cmd
in


let filemodel = "../sdata/"^model in
let fileactions = "../sdata/"^actions in
let filegoal = "../sdata/"^goal in
let opt = sport in
let language = lang in
let fileoptions = "../sdata/05_options.txt" in


flush stdout; flush stderr;
Utils.print "Select TouIST\n";
flush stdout; flush stderr;
let returncode = (command "./touist.exe --version") in
Utils.print "\n";

flush stdout; flush stderr;
if returncode == 0 then Utils.print ""
else begin Utils.eprint "[Error %d] please install TouIST with : brew install touist\n" returncode; exit returncode; end;


let start = Unix.gettimeofday () in 
let contains s1 s2 =
  try
    let len = String.length s2 in
    for i = 0 to String.length s1 - len do
      if String.sub s1 i len = s2 then raise Exit
    done;
    false
  with Exit -> true  in

let rec print_list = function 
  [] -> ()
  | e::l -> print_string e ; print_string " " ; print_list l in


let rec print_numbers oc = function 
  | [] -> ()
  | e::tl -> Printf.fprintf oc "%s\n" e; print_numbers oc tl in  


(* Permutations *)
let rec insert x lst =
  match lst with
  | [] -> [[x]]
  | h::t -> 
    (x::lst) :: (List.map (fun el -> h::el) (insert x t)) in

let rec perm lst =
  match lst with
  | [] -> [lst]
  | h::t -> 
  List.flatten (List.map (insert h) (perm t)) in    
(* End Permutations *)

  let flatten l =
  let rec loop res = function
    | [] -> List.rev res
    | h::t -> loop (List.rev_append h res) t  in
              loop [] l in  

let read_line i = try Some (input_line i) with End_of_file -> None  in
let lines_from_files filename = 
let rec lines_from_files_aux i acc = match (read_line i) with 
        | None -> List.rev acc
        | Some s -> lines_from_files_aux i (s :: acc) in 
        lines_from_files_aux (open_in filename) [] in
        let rec print_numbers oc = function 
        | [] -> ()
        | e::tl -> Printf.fprintf oc "%s\n" e; print_numbers oc tl in  


let extract_desire (ls : string) : string =  "-e _" ^opt ^"_ass_"^String.sub ls ((String.rindex_from ls ((String.length ls) - 1) '(') + 1) 3
  in
        
let rec assignment (ls : string list) : string list=
          match ls with
          | [] -> []
          | x :: xs -> (extract_desire x) :: assignment xs  in      


    

let common_files() = 
  let assignments_list =  lines_from_files ("../sdata/00_delta0.txt") in 
  let () =
    let preferences = assignment assignments_list in
        (*print_list preferences; *)
        filter_list := (String.concat " " preferences);
        (* Printf.printf "Filter list : \n%s \n" !filter_list; *)
        in


  let start11 = Unix.gettimeofday () in 
  let string_of_command () =
  (*let tmp_file = "../sdata/00_cp_pre_syntax.txt" in*)
  let tmp_file = "../sdata/00_tempo.txt" in
  (*let _ = Sys.command @@ "grep -F _'"^opt^"'_ "^fileactions^" > solvedatacp/"^opt^"_tmp_actions.txt" in*)
  let _ = Sys.command @@ "grep -e ideal_h_"^opt^" -e _"^opt^"_ass_danger"^" "^(!filter_list)^" "^fileactions^" > solvedatacp/"^opt^"_tmp_actions.txt" in
  let chan = open_in tmp_file in
  close_in chan
  in
  string_of_command() ;

  let string_of_command () =
  let tmp_file = "../sdata/00_tempo.txt" in
  let _ = Sys.command @@ "grep -F _'danger' solvedatacp/"^opt^"_tmp_actions.txt > solvedatacp/"^opt^"_tmp_actions_danger.txt" in
  let chan = open_in tmp_file in
  close_in chan
  in
  string_of_command();

  let string_of_command4 () =
    let tmp_file = "../sdata/00_tempo.txt" in
     let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(m,h,//g' -e 's/)//g' solvedatacp/"^opt^"_tmp_actions_danger.txt")   in
     let chan = open_in tmp_file in
     close_in chan
   in
   string_of_command4();  


  let tmp_file = "solvedatacp/"^opt^"_tmp_actions_danger.txt" in
  let chan = open_in tmp_file in
  try
    while true do
      action_danger := input_line chan;
    done;
    with End_of_file -> close_in chan; 
  


 



  in




  
if (encoding = 1) then (* SAT *)
begin
  Printf.printf "Performing SAT process ...\n";

let plan m opt = 

  (*Printf.printf "Processing Plans of size = %i \n" !m;*)

              (*Generates the common files to both SAT and QBF processes *)
              linesper := perm (lines_from_files ("solvedatacp/"^opt^"_tmp_actions.txt"));
              let reslst2 =  flatten !linesper in


              let precondition action =
                if (contains action "ideal") then "[m]"^action^" and justif_h_"^opt^")"
                else if (contains action "_danger_") then "[m]"^action^""
                else "[m]("^action^" and ("^(!action_danger)^" => th_"^(!action_danger)^" ))"  in
            



              let string_of_command4 () =
              let tmp_file = "../sdata/00_tempo.txt" in
              let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(m,h,//g' solvedatacp/"^opt^"_tmp_actions.txt") in
              let chan = open_in tmp_file in
                        close_in chan
                    in
                    string_of_command4(); 

         let () =
          let oc = open_out (Printf.sprintf "solvedatacp/%s_pato_%i.txt" opt !m) in
          print_numbers oc reslst2;
          close_out oc in
          (*Printf.eprintf "== solve time permutations 0  === MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start10);  *)

(**)            let start11 = Unix.gettimeofday () in 


                let string_of_command4 () =
                let tmp_file = "../sdata/00_tempo.txt" in
                let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(m,h,/plusa({2}(/g' solvedatacp/%s_pato_%i.txt" opt !m) in
                let chan = open_in tmp_file in
                          close_in chan
                      in
                      string_of_command4();        

    let lines = ref "" in
    let lines2 = ref "" in
    let action = ref "" in
    let i = ref 1 in
    let tmp_file = Printf.sprintf "solvedatacp/%s_pato_%i.txt" opt !m in
    let chan = open_in tmp_file in
    let j = ref 0 in
    let touistcode2 = ref 0 in
    j := 0;
    try
      while true do
        j := !j + 1;
        action := input_line chan;



        
        let start5 = Unix.gettimeofday () in
        lines := "("^ (precondition !action) ^" and "^ !action ^", "^ !lines;
        lines2 := !action ^"\n"^ !lines2; (* Only consider the operator without the pre-condition this is to show to the final user *)

        if !j = !m then  begin 
                        (*Printf.printf "DESPUES DEL IF %s - %i \n" !lines !m;*)
                        let start5 = Unix.gettimeofday () in
                        let string_of_command4 () =
                                
                              let tmp_file = "../sdata/00_tempo.txt" in
                              let _ = 
                              Sys.command (Printf.sprintf "echo '%s' >> solvedatacp/%s_pato_seq_%i_%i.txt" !lines opt !m !i);  
                              Sys.command (Printf.sprintf "echo '%s' > solvedatacp/%s_plan_final2.txt" !lines2 opt);
                                  in
                              let chan = open_in tmp_file in
                              close_in chan
                              in
                              string_of_command4();  

                        
                        
                        let string_of_command4 () =
                              let tmp_file = "../sdata/00_tempo.txt" in
                              let _ = Sys.command (Printf.sprintf "sed -i -e 's/]/)/g' -e 's/\[/(/g' -e 's/(m)plusa/[m]/g' -e 's/([m]({2}/([m]/g' solvedatacp/%s_pato_seq_%i_%i.txt" opt !m !i)   in
                              let chan = open_in tmp_file in
                              close_in chan
                              in
                              string_of_command4();  

                              
                        (* Here we generate the Plan formula, putting together the 01_ini_state / 02_actions = pato_seq_%i_%i.txt / 03_goal = 03_goalb.txt*)    
                        let string_of_command5 () =
                                let tmp_file = "../sdata/00_tempo.txt" in
                                let _ = Sys.command (Printf.sprintf "cat %s ../sdata/99_implies.txt solvedatacp/%s_pato_seq_%i_%i.txt ../sdata/99_boxm.txt %s >  solvedatacp/%s_formula_%i_%i.txt" filemodel opt !m !i filegoal opt !m !i)   in 
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command5();  

                            (* Here with close with ")" the seq of plusa operators starting from the inner one *)  
                            for j = 0 to !m do


                              let string_of_command4 () =
                                      
                                      let tmp_file = "../sdata/00_tempo.txt" in
                                      let _ = Sys.command (Printf.sprintf "echo '))' >> solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                      let chan = open_in tmp_file in
                                      close_in chan
                                    in
                                    string_of_command4(); 

                            done;          


                              let string_of_command4d() =
                                let tmp_file = "../sdata/00_tempo.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i -e '1 i\ (not ([m](' -e 's/),/,/g' -e '$ s/.$//' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4d();                                  


                              (* Here we only replace the {2} by th_ *)    

                              let string_of_command4b() =
                                let tmp_file = "../sdata/00_tempo.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i -e 's/{2}(/th_/g' -e 's/m](th_/m](/g' -e 's/) and justif_h/ and justif_h/g' -e 's/(plusa(th_/((/g' -e 's/=> plusa(th_/=> (th_/g' -e 's/((m)((/([m]((/g' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4b();  


                              (* Encapsulates the Planning process *)  
                              let process () =     
                                (*Printf.printf "Testing formula_%i_%i.txt \n" !m !i;*)
                                flush stdout; flush stderr;

                              (* TRANSLATOR generates Prop Logic formula for touist.exe *)    

                              let start2 = Unix.gettimeofday () in 
                              command (Printf.sprintf "./translator.exe --sat solvedatacp/%s_formula_%i_%i.txt" opt !m !i);
                              let start3 = Unix.gettimeofday () in 
                              touistcode2 := (command (Printf.sprintf "./touist.exe ../sdata/proplogic/%s_formula_%i_%i.txt --solve" opt !m !i));

                              Printf.printf "Plan_%i_%i_%s.txt \n" !m !i opt;
                              flush stdout; flush stderr;

                              let start8 = Unix.gettimeofday () in

                              if !touistcode2 = 8 then 

                                 begin
                                    Printf.printf "Plan of size %i found  : \n" !m;
                                    flush stdout; flush stderr;

                                  let string_of_command4b() =
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "cat solvedatacp/%s_plan_final2.txt > solvedatacp/plan_final_show_%s.txt" opt opt)   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                  in
                                  string_of_command4b();  



                                  let string_of_command4 () =
                                        let tmp_file = "../sdata/00_tempo.txt" in
                                        let _ = Sys.command (Printf.sprintf "cat solvedatacp/plan_final_show_%s.txt > solvedatacp/plan_final_show2_%s.txt" opt opt)   in
                                        let chan = open_in tmp_file in
                                        close_in chan
                                        in
                                        string_of_command4();                                       

                                  let string_of_command4 () =
                                          let tmp_file = "../sdata/00_tempo.txt" in
                                          let _ = Sys.command (Printf.sprintf "sed -i -e 's/plusa({2}(val_//g' -e 's/_ass_/ /g' -e 's/_/ is /g' -e 's/)//g' solvedatacp/plan_final_show2_%s.txt" opt)   in
                                          let chan = open_in tmp_file in
                                          close_in chan
                                          in
                                          string_of_command4();                                         

                                  let string_of_command4 () =
                                          let tmp_file = "../sdata/00_tempo.txt" in
                                          let _ = Sys.command (Printf.sprintf "cat solvedatacp/plan_final_show2_%s.txt | head -n -2 > solvedatacp/plan_final_show3_%s.txt" opt opt)   in
                                          let chan = open_in tmp_file in
                                          close_in chan
                                          in
                                          string_of_command4();          
                                          
                                          
                                  let string_of_command4 () =
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "cat solvedatacp/plan_final_show2_%s.txt | head -n -2 > solvedatacp/plan_final_show3_%s.txt" opt opt)   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4();      


                                  let string_of_command4 () =
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "head -n 1 solvedatacp/plan_final_show3_%s.txt > solvedatacp/plan_final_show4_%s.txt" opt opt)   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4();       
                                    

                                  let string_of_command4 () =
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "tail -n +2 solvedatacp/plan_final_show3_%s.txt > solvedatacp/plan_final_show4b_%s.txt" opt opt)   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4();                                                   





                                  let string_of_command4 () =
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "awk '{print $1}' solvedatacp/plan_final_show4_%s.txt > solvedatacp/option_%s.out" opt opt)   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4();                                         


                                  let string_of_command4 () =
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "awk '{print $4}' solvedatacp/plan_final_show4_%s.txt > solvedatacp/option_danger_%s.out" opt opt)   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4();                                                 
                                    

                                  let tmp_file = "solvedatacp/option_"^opt^".out" in
                                  let chan = open_in tmp_file in
                                  try
                                    while true do
                                      ideal_option := input_line chan;
                                    done;
                                    with End_of_file -> close_in chan; 



                                  if language = "2" then                                    
                                  begin
                                    let string_of_command4() =
                                      let tmp_file = "../sdata/00_tempo.txt" in
                                      let _ = Sys.command (Printf.sprintf "sed -i -e 's/low/faible/g' -e 's/med/modéré/g' -e 's/high/important/g' solvedatacp/option_danger_%s.out" opt)   in                                      

                                      let chan = open_in tmp_file in
                                      close_in chan
                                      in
                                      string_of_command4(); 
                                  end;


                                  let tmp_file = "solvedatacp/option_danger_"^opt^".out" in
                                  let chan = open_in tmp_file in
                                  try
                                    while true do
                                      ideal_option_danger := input_line chan;
                                    done;
                                    with End_of_file -> close_in chan;
                                            
                                            


                                  let string_of_command4 () =
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "sed -i -e 's/%s //g' solvedatacp/plan_final_show4b_%s.txt" !ideal_option opt)   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4();                                             


                                  let string_of_command4 () =
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "awk 'NR==FNR {h[$1] = $2; next} {print h[$1],$2,$3}' ../sdata/02_actions_translate.txt solvedatacp/plan_final_show4b_%s.txt > solvedatacp/plan_final_show5b_%s.txt" opt opt)   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4();                                             


                                    
                                 
                                  if language = "2" then
                                  begin
                                    let string_of_command4() =
                                      let tmp_file = "../sdata/00_tempo.txt" in
                                      let _ = Sys.command (Printf.sprintf "sed -i -e 's/intensity/Son niveau d’intensité est/g' -e 's/sociality/Il se pratique/g' -e 's/environment/C’est un sport/g' -e 's/location/C’est un sport d’/g' -e 's/cost/Son coût est/g' -e 's/dangerousness/Son niveau d’adrénaline est/g' -e 's/is//g' solvedatacp/plan_final_show5b_%s.txt" opt)   in
                                      let _ = Sys.command (Printf.sprintf "sed -i -e 's/land/terrestre/g' -e 's/water/aquatique/g' -e 's/indoor/intérieur/g' -e 's/outdoor/extérieur/g' -e 's/mixed/mixed/g' -e 's/single/seul/g' -e 's/team/en équipe/g' -e 's/low/faible/g' -e 's/med/modéré/g' -e 's/high/important/g' -e 's/  / /g' solvedatacp/plan_final_show5b_%s.txt" opt)   in
                                      let _ = Sys.command (Printf.sprintf "sed -i -e 's/Il se pratique mixed/Il se pratique seul mais peut se pratiquer en équipe/g' -e 's/C’est un sport d’ mixed/C’est un sport d’ intérieur et extérieur/g' solvedatacp/plan_final_show5b_%s.txt" opt)   in

(*
Il se pratique mixte
Il se pratique seul mais peut se pratiquer en équipe

C’est un sport d’ mixed
C’est un sport d’ intérieur et extérieur
*)

                                      let chan = open_in tmp_file in
                                      close_in chan
                                      in
                                      string_of_command4();                                             
                                  end;

                                  explanation := lines_from_files ("solvedatacp/plan_final_show5b_"^opt^".txt");
                                  final_explanation :=  String.concat ". " !explanation;                                  
                                  final_explanation := !final_explanation ^ "."; 





                                        if !ideal_option = "te" then 
                                                    if language = "2" then
                                                              ideal_sport:= "le tennis"
                                                    else  
                                                              ideal_sport:= "tennis";

                                        if !ideal_option = "di" then (*ideal_sport:= "diving";*)
                                                  if language = "2" then
                                                            ideal_sport:= "la plongée"
                                                  else  
                                                            ideal_sport:= "diving";                                        

                                        if !ideal_option = "so" then (*ideal_sport:= "soccer";*)
                                                  if language = "2" then
                                                            ideal_sport:= "le football"
                                                  else  
                                                            ideal_sport:= "soccer";                                        

                                        if !ideal_option = "yo" then (*ideal_sport:= "yoga";*)
                                                  if language = "2" then
                                                            ideal_sport:= "le yoga"
                                                  else  
                                                            ideal_sport:= "yoga";                                        


                                        if !ideal_option = "sq" then (* ideal_sport:= "squash"; *)
                                                  if language = "2" then
                                                            ideal_sport:= "le squash"
                                                  else  
                                                            ideal_sport:= "squash";                                                                                

                                        if !ideal_option = "sw" then (* ideal_sport:= "swimming"; *)
                                                  if language = "2" then
                                                            ideal_sport:= "la natation"
                                                  else  
                                                            ideal_sport:= "swimming";                                                                                
                                        
                                        if !ideal_option = "ru" then (* ideal_sport:= "running"; *)
                                                  if language = "2" then
                                                            ideal_sport:= "la marche"
                                                  else  
                                                            ideal_sport:= "running";                                                                                                                      


                                        if !ideal_option = "hr" then (* ideal_sport:= "horse riding"; *)
                                                  if language = "2" then
                                                            ideal_sport:= "l’équitation"
                                                  else  
                                                            ideal_sport:= "horse riding";                                                                                                                   



                                        if language = "2" then              
                                          let string_of_command4 () =
                                            Printf.printf "Idioma = %s \n" language;
                                            let tmp_file = "../sdata/00_tempo.txt" in
                                            (* let _ = Sys.command (Printf.sprintf "echo 'Je trouvé que %s a un niveau %s de dangerosité.' > solvedatacp/final_%s.out" !ideal_sport !ideal_option_danger opt)   in *)
                                            (*let _ = Sys.command (Printf.sprintf "echo 'I found that %s has a %s dangerousness level.' > solvedatacp/final_%s.out" !ideal_sport !ideal_option_danger opt)   in*)                                            
                                            (*let _ = Sys.command (Printf.sprintf "echo 'Il me semble que %s a plutôt un niveau d'adrénaline %s.' > solvedatacp/final_%s.out" !ideal_sport !ideal_option_danger opt) 
                                              in*)
                                            let _ = Sys.command (Printf.sprintf "echo 'Il me semble que %s a plutôt un niveau d'\\''adrénaline %s.' > solvedatacp/final_%s.out" !ideal_sport !ideal_option_danger opt)   in                                              
                                            let _ = Sys.command (Printf.sprintf "echo 'De plus, ce sport comble vos envies car: ' >> solvedatacp/final_%s.out" opt)   in
                                            let _ = Sys.command (Printf.sprintf "echo '%s' >> solvedatacp/final_%s.out" !final_explanation opt)   in
                                            let _ = Sys.command (Printf.sprintf "echo 'Pour toutes ces raisons, je recommande %s comme le sport idéal pour vous.' >> solvedatacp/final_%s.out" !ideal_sport opt)   in
                                            let _ = Sys.command (Printf.sprintf "cat solvedatacp/final_%s.out > solvedatacp/plans/plan_final_show_%s.txt" opt opt)   in
                                            let _ = Sys.command (Printf.sprintf "cat solvedatacp/final_%s.out > solvedatacp/plan_final_show.txt" opt)   in

                                            let chan = open_in tmp_file in
                                            close_in chan
                                            in
                                            string_of_command4();      
                                            Printf.eprintf "== solve PLANNER time: %f sec\n" (Unix.gettimeofday () -. start); (*- @@@*)  
                                            exit 0;                                                                              


                                        else 
                                                let string_of_command4 () =
                                                  Printf.printf "Idioma = %s \n" language;
                                                  let tmp_file = "../sdata/00_tempo.txt" in
                                                  let _ = Sys.command (Printf.sprintf "echo 'I found that %s has a %s dangerousness level.' > solvedatacp/final_%s.out" !ideal_sport !ideal_option_danger opt)   in
                                                  let _ = Sys.command (Printf.sprintf "echo 'In addition, it satisfies your desires because: ' >> solvedatacp/final_%s.out" opt)   in
                                                  let _ = Sys.command (Printf.sprintf "echo '%s' >> solvedatacp/final_%s.out" !final_explanation opt)   in
                                                  let _ = Sys.command (Printf.sprintf "echo 'For all these reasons, I recommend %s as the ideal sport for you ' >> solvedatacp/final_%s.out" !ideal_sport opt)   in
                                                  let _ = Sys.command (Printf.sprintf "cat solvedatacp/final_%s.out > solvedatacp/plans/plan_final_show_%s.txt" opt opt)   in
                                                  let _ = Sys.command (Printf.sprintf "cat solvedatacp/final_%s.out > solvedatacp/plan_final_show.txt" opt)   in
      
                                                  let chan = open_in tmp_file in
                                                  close_in chan
                                                  in
                                                  string_of_command4();                                        

                                                  let plan_exist = Sys.file_exists "solvedatacp/plan_final_show.txt" in
                                                  if (plan_exist = false) then 
                                                    begin
                                                      let string_of_command4b () =
                                                        Printf.printf "Dentro del plan_exist\n";
                                                        let tmp_file = "../sdata/00_tempo.txt" in
                                                        let _ = Sys.command (Printf.sprintf "cat solvedatacp/final_%s.out > solvedatacp/plan_final_show.txt" opt)   in
                                                        let chan = open_in tmp_file in  
                                                        close_in chan
                                                        in
                                                        string_of_command4b();  
                                                    end;

                                                  (* Read the option*)
                                                  Printf.eprintf "== solve PLANNER time: %f sec\n" (Unix.gettimeofday () -. start); (*- @@@*)  
                                                  exit 0;

                                  end                                
                                else  
                                  begin
                                  let string_of_command4w () =
                                                          
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "cat 'solvedatacp/%s_pato_seq_%i_%i.txt' > solvedatacp/plan_final_%s.txt" opt !m !i opt)   in
                                    flush stdout; flush stderr;
                                    let chan = open_in tmp_file in
                                    close_in chan
                                  in
                                  string_of_command4w(); 
                                  (*Printf.eprintf "== solve PLANNER - NO PLAN  time: %f sec\n" (Unix.gettimeofday () -. start); (*- @@@*)  *)
                                  end    
                              in
                              process();     
                                

                            i := 1 + !i;
                            j := 0;
                            lines := "";
                            lines2 := "";
                        end

      done;
     
      
        
     with End_of_file -> close_in chan; 
                  
in

(*
let _ = Sys.command (Printf.sprintf "cat 'solvedatacp/%s_pato_seq_%i_%i.txt' > solvedatacp/plan_final.txt" opt !m !i)   in
*)


let start7 = Unix.gettimeofday () in

let returncode = (Sys.command (Printf.sprintf "rm solvedatacp/%s_*.*" sport)) in
let returncode = (Sys.command (Printf.sprintf "rm ../sdata/proplogic/%s_*.*" sport)) in
let returncode = (Sys.command (Printf.sprintf "rm solvedatacp/plan_*_%s.*" sport)) in
let returncode = (Sys.command (Printf.sprintf "rm solvedatacp/*_%s.out" sport)) in


common_files();
psize := (List.length (lines_from_files ("solvedatacp/"^opt^"_tmp_actions.txt")));
plan psize sport;

Printf.printf " Plan not found \n";

let string_of_command4b() =
  let tmp_file = "../sdata/00_tempo.txt" in
  let _ = Sys.command (Printf.sprintf "echo 'Sorry, it was not possible to find an ideal sport for you' > solvedatacp/noplans/plan_final_show_%s.txt" opt)   in
  let chan = open_in tmp_file in
  close_in chan
in
string_of_command4b();  

let plan_exist = Sys.file_exists "solvedatacp/plan_final_show.txt" in
if (plan_exist = false) then 
  begin
    let string_of_command4b() =
      let tmp_file = "../sdata/00_tempo.txt" in
      let _ = Sys.command (Printf.sprintf "echo 'Sorry, it was not possible to find an ideal sport for you' > solvedatacp/plan_final_show.txt")   in
      let chan = open_in tmp_file in
      close_in chan
    in
    string_of_command4b();  
  end;

exit 0;
end;

(*Starting the QBF planning process*)
if (encoding = 2) then (* QBF *)
begin
  Printf.printf "Performing QBF process ...\n";

  let plan m opt = 

                (*Generates the common files to both SAT and QBF processes *)
                (* Generates all possible permutations with items in opt_tmp_actions.txt *)
                linesperx := (lines_from_files ("solvedatacp/"^opt^"_tmp_actions.txt"));
                let reslst2 =  !linesperx in
  

                let selector action =
                  "sel_th_"^action^"_th_"^action  in                


                let precondition action =
                  if (contains action "ideal") then "[m]("^action^" and justif_h_"^opt^")"
                  else if (contains action "_danger_") then "[m]("^action^")"
                  else "[m]("^action^" and ("^(!action_danger)^" => th_"^(!action_danger)^" ))"  in
              
                  let string_of_command4 () =
                    let tmp_file = "../sdata/00_tempo.txt" in
                    let _ = Sys.command (Printf.sprintf "cat solvedatacp/"^opt^"_tmp_actions.txt > solvedatacp/"^opt^"_tmp_actions_th.txt") in
                    let chan = open_in tmp_file in
                              close_in chan
                          in
                          string_of_command4();   
                
                  let string_of_command4 () =
                    let tmp_file = "../sdata/00_tempo.txt" in
                    let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(m,h,/th_/g' -e 's/.$//' solvedatacp/"^opt^"_tmp_actions_th.txt") in
                    let chan = open_in tmp_file in
                              close_in chan
                          in
                          string_of_command4(); 


                  let string_of_command4 () =
                    let tmp_file = "../sdata/00_tempo.txt" in
                    let _ = Sys.command (Printf.sprintf "cat solvedatacp/"^opt^"_tmp_actions_th.txt > ../sdata/02_actionsb.txt") in
                    let chan = open_in tmp_file in
                              close_in chan
                          in
                          string_of_command4(); 


(* Generate the SET 
$Op=[th_ideal_h_te_, th_val_te_ass_env_land, th_val_te_ass_danger_med, th_val_te_ass_loc_mixed, th_val_te_ass_soc_mixed, th_val_te_ass_intens_med]
*)
          let string_of_command4 () =
            let tmp_file = "../sdata/00_tempo.txt" in
            let _ = Sys.command (Printf.sprintf "cat solvedatacp/"^opt^"_tmp_actions_th.txt > solvedatacp/"^opt^"_tmp_actions_set.txt") in
            let chan = open_in tmp_file in
                        close_in chan
                  in
                  string_of_command4(); 

          let string_of_command4 () =
            let tmp_file = "../sdata/00_tempo.txt" in
            let _ = Sys.command (Printf.sprintf "sed -i -e '1s/^/$Op=[/' -e 's/$/,/' -e '$ s/.$//' -e '$a]' solvedatacp/"^opt^"_tmp_actions_set.txt") in
            let chan = open_in tmp_file in
                        close_in chan
                  in
                  string_of_command4(); 
        
          let () =
            let oc = open_out (Printf.sprintf "solvedatacp/%s_pato_%i.txt" opt !m) in
            print_numbers oc reslst2;
            close_out oc in
  
          let start11 = Unix.gettimeofday () in 
  
  
          let string_of_command4 () =
          let tmp_file = "../sdata/00_tempo.txt" in
          let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(m,h,//g' -e 's/.$//g' solvedatacp/%s_pato_%i.txt" opt !m) in
          let chan = open_in tmp_file in
                    close_in chan
                in
                string_of_command4();      
                        
                        
                        
  
      let lines = ref "" in
      let lines2 = ref "" in
      let action = ref "" in
      let i = ref 1 in
      let tmp_file = Printf.sprintf "solvedatacp/%s_pato_%i.txt" opt !m in
      let chan = open_in tmp_file in
      let j = ref 0 in
      let touistcode2 = ref 0 in
      j := 0;
      try
        while true do
          j := !j + 1;
          action := input_line chan;
  
          let start5 = Unix.gettimeofday () in
          lines := "("^(selector !action)^ " => phi(th_"^(!action)^","^(precondition !action)^")) and "^ !lines;
          lines2 := !action ^"\n"^ !lines2; (* Only consider the operator without the pre-condition this is to show to the final user *)
 

          if !j = !m then  begin 
                          let start5 = Unix.gettimeofday () in
                          let string_of_command4 () =
                                  
                                let tmp_file = "../sdata/00_tempo.txt" in
                                let _ = 
                                Sys.command (Printf.sprintf "echo '%s' >> solvedatacp/%s_pato_seq_%i_%i.txt" !lines opt !m !i);  
                                Sys.command (Printf.sprintf "echo '%s' > solvedatacp/%s_plan_final2.txt" !lines2 opt);
                                (*Printf.eprintf "== solve ECHO time: %f sec\n" (Unix.gettimeofday () -. start);*) in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4();  
  

                                
                          let string_of_command4 () =
                                let tmp_file = "../sdata/00_tempo.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i -e '1 i\((' -e '$ s/.$//' -e '$ s/.$//' -e '$ s/.$//' -e '$ s/.$//' -e '$a) and' solvedatacp/%s_pato_seq_%i_%i.txt" opt !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4();  

                              
                          (* Here we generate the QBF Plan formula, putting together the 01_ini_state / 02_actions = pato_seq_%i_%i.txt / 03_goal = 03_goalb.txt*)   
                          (* In addition, we need to include the Set of Axioms for the selecttors at the beginning of the formula *)   
                          let string_of_command5 () =
                                  let tmp_file = "../sdata/00_tempo.txt" in
                                  let _ = Sys.command (Printf.sprintf "cat solvedatacp/%s_tmp_actions_set.txt ../sdata/00_axioms_selectors.txt ../sdata/99_box_inistate.txt %s ../sdata/99_implies.txt solvedatacp/%s_pato_seq_%i_%i.txt ../sdata/99_psi.txt %s >  solvedatacp/%s_formula_%i_%i.txt" opt filemodel opt !m !i filegoal opt !m !i)   in 
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command5();  
  

                              (* Here with close with ")" the seq of plusa operators starting from the inner one *)  
                              for j = 0 to 1 do
                                  let string_of_command4 () =
                                        
                                        let tmp_file = "../sdata/00_tempo.txt" in
                                        let _ = Sys.command (Printf.sprintf "echo '))' >> solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                        let chan = open_in tmp_file in
                                        close_in chan
                                      in
                                      string_of_command4(); 
                              done;          
  
  
                                let string_of_command4d() =
                                  let tmp_file = "../sdata/00_tempo.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i 's/),/,/g' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4d();                                  
  
  
                                let string_of_command4e() =
                                  let tmp_file = "../sdata/00_tempo.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i '$ s/.$//' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4e();                                
  
  
                                (* Here we only replace the {2} by th_ *)    
  
                                let string_of_command4b() =
                                  let tmp_file = "../sdata/00_tempo.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i -e 's/{2}(/th_/g' -e 's/m](th_/m](/g' -e 's/) and justif_h/ and justif_h/g' -e 's/(plusa(th_/((/g' -e 's/=> plusa(th_/=> (th_/g' -e 's/((m)((/([m]((/g' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4b();  
  
                                (* Encapsulates the Process Plan procedure *)  
                                let process () =     
                                  flush stdout; flush stderr;
  
                                (* Translator generates QBF formula for touist.exe *)    
  
                                let start2 = Unix.gettimeofday () in 
                                (*command (Printf.sprintf "./translator_qbf2.exe solvedatacp/%s_formula_%i_%i.txt" opt !m !i);*)
                                command (Printf.sprintf "./translator.exe --qbf solvedatacp/%s_formula_%i_%i.txt" opt !m !i);
                                (*Printf.eprintf "== solve time TRANSLATOR == MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start2);*)
                                let start3 = Unix.gettimeofday () in 
                                touistcode2 := (command (Printf.sprintf "./touist.exe --qbf ../sdata/proplogic/qbf_%s_formula_%i_%i.txt --solver=rareqs | grep -F '1 sel_' > %s.out" opt !m !i opt));

                                let string_of_command4 () =
                                  let tmp_file = "../sdata/00_tempo.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i -e 's/1 sel_th_//g' -e 's/_th_/ /g' %s.out" opt)   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4(); 


                                let string_of_command4 () =
                                  let tmp_file = "../sdata/00_tempo.txt" in
                                  let _ = Sys.command (Printf.sprintf "awk '{print $1}' %s.out  > %s.out2" opt opt)   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4();                                   

                                let string_of_command4 () =
                                  let tmp_file = "../sdata/00_tempo.txt" in
                                  let _ = Sys.command (Printf.sprintf "awk '{ tot[$0]++ } END { for (i in tot) print tot[i],i }' %s.out2 | sort -r > solvedatacp/plan_final_qbf.txt" opt)   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4(); 
  


                                Printf.printf "Plan_%i_%i_%s.txt \n" !m !i opt;  (*- @@@ *)
                                flush stdout; flush stderr;

  
                                
                                if !touistcode2 = 0 then 
  
                                   begin
                                      Printf.printf "Plan of size 1 found  : \n"; (* For QBF only one plan*)
                                      flush stdout; flush stderr;
  
                                    let string_of_command4b() =
                                      let tmp_file = "../sdata/00_tempo.txt" in
                                      let _ = Sys.command (Printf.sprintf "cat solvedatacp/%s_plan_final2.txt > solvedatacp/plan_final_show.txt" opt)   in
                                      let chan = open_in tmp_file in
                                      close_in chan
                                    in
                                    string_of_command4b();  
  

  
                                    exit 0;
  
  
                                    end                                
                                  else  
                                    begin
                                    let string_of_command4w () =
                                                            
                                      let tmp_file = "../sdata/00_tempo.txt" in
                                      let _ = Sys.command (Printf.sprintf "cat 'solvedatacp/%s_pato_seq_%i_%i.txt' > solvedatacp/plan_final.txt" opt !m !i)   in
                                      flush stdout; flush stderr;
                                      let chan = open_in tmp_file in
                                      close_in chan
                                    in
                                    string_of_command4w(); 
                                    end    
                                in
                                process();     
                                  
  
                              i := 1 + !i;
                              j := 0;
                              lines := "";
                              lines2 := "";
                          end
  
        done;
       
        
          
       with End_of_file -> close_in chan; 
                    
  in
  
  
  
  let start7 = Unix.gettimeofday () in
  
  let returncode = (Sys.command (Printf.sprintf "rm solvedatacp/%s_*.*" sport)) in
  let returncode = (Sys.command (Printf.sprintf "rm ../sdata/proplogic/%s_*.*" sport)) in
  let returncode = (Sys.command (Printf.sprintf "rm solvedatacp/plan_*.*")) in
  


  common_files();
  psize := (List.length (lines_from_files ("solvedatacp/"^opt^"_tmp_actions.txt")));
  plan psize sport;

  
  Printf.printf " Plan not found \n";
  
  let string_of_command4b() =
    let tmp_file = "../sdata/00_tempo.txt" in
    let _ = Sys.command (Printf.sprintf "echo 'Sorry, it was not possible to find an ideal sport for you' > solvedatacp/plan_final_show.txt")   in
    let chan = open_in tmp_file in
    close_in chan
    
  in
  string_of_command4b();  
  
  
  
  exit 0;



end; 

end


