#! /usr/bin/env node
// To test it: go to where is touistjs_test.js and
//     node ./touistjs_test.js

var t = require("_build/default/src/js/touistjs.bc.js");

console.log(t.latex("bigand $i in [1..2]: p($i end"));
